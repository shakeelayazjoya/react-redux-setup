module.exports = {
  presets: ['react-app'],
};
