/** @type {import('@react-native-community/cli-types').UserConfig } */
const config = {
  project: {
    ios: {
      automaticPodsInstallation: true,
    },
  },
}

export default config
